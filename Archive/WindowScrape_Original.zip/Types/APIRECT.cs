﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace WindowScrape.Types
{
    internal struct RECT
    {
        public int Left;
        public int Top;
        public int Right;
        public int Bottom;
    }
}
